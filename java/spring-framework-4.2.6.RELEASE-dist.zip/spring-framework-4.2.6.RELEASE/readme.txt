Spring Framework version 4.2.6.RELEASE
=====================================================================================

To find out what has changed since earlier releases, see the 'Change Log' section at
https://jira.spring.io/browse/SPR

Please consult the documentation located within the 'docs/spring-framework-reference'
directory of this release and also visit the official Spring Framework home at
http://projects.spring.io/spring-framework/

There you will find links to the forum, issue tracker, and other resources.

See https://github.com/spring-projects/spring-framework#readme for additional
information including instructions on building from source.
